"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertTriangle,
  Phone,
  Shield,
  Radio,
  Zap,
  Droplets,
  Package,
  Clock,
  CheckCircle,
  XCircle,
  Info,
} from "lucide-react"

export default function EmergencyInfo() {
  const [activeTab, setActiveTab] = useState("preparation")

  const emergencyContacts = [
    { name: "Notruf (Polizei, Feuerwehr, Rettung)", number: "112", description: "Für alle Notfälle" },
    { name: "Polizei", number: "110", description: "Bei Verbrechen und Gefahren" },
    {
      name: "Ärztlicher Bereitschaftsdienst",
      number: "116 117",
      description: "Medizinische Hilfe außerhalb der Sprechzeiten",
    },
    { name: "Giftnotruf", number: "030 19240", description: "Bei Vergiftungen (Berlin)" },
    { name: "Telefonseelsorge", number: "0800 111 0 111", description: "Psychische Unterstützung" },
  ]

  const emergencySupplies = [
    { category: "Wasser", items: ["2 Liter pro Person/Tag für 10 Tage", "Wasserreinigungstabletten"], icon: Droplets },
    {
      category: "Nahrung",
      items: ["Konserven, Nudeln, Reis", "Dauerbrot, Zwieback", "Honig, Marmelade"],
      icon: Package,
    },
    {
      category: "Medikamente",
      items: ["Persönliche Medikamente", "Erste-Hilfe-Set", "Schmerzmittel, Fiebermittel"],
      icon: Shield,
    },
    { category: "Energie", items: ["Batterien, Powerbank", "Kerzen, Streichhölzer", "Taschenlampe"], icon: Zap },
    {
      category: "Kommunikation",
      items: ["Kurbelradio", "Handy mit Ladegerät", "Wichtige Telefonnummern"],
      icon: Radio,
    },
  ]

  const warningSignals = [
    {
      name: "Dauerton (1 Minute)",
      meaning: "Entwarnung",
      action: "Gefahr ist vorbei, normale Aktivitäten können wieder aufgenommen werden",
      type: "safe",
    },
    {
      name: "Heulton (1 Minute auf/ab)",
      meaning: "Warnung vor Gefahr",
      action: "Sofort Schutzraum aufsuchen, Radio/TV einschalten, Anweisungen befolgen",
      type: "warning",
    },
    {
      name: "Unterbrochener Heulton",
      meaning: "ABC-Alarm (Chemie/Atom)",
      action: "Sofort in geschlossene Räume, Fenster/Türen schließen, Belüftung ausschalten",
      type: "danger",
    },
  ]

  const bunkerBehavior = [
    "Ruhe bewahren und Panik vermeiden",
    "Anweisungen des Bunker-Personals befolgen",
    "Eigene Vorräte mitbringen (Wasser, Medikamente)",
    "Handy stumm schalten, Akku sparen",
    "Platz für andere schaffen",
    "Keine Gerüchte verbreiten",
    "Bei Problemen Personal informieren",
    "Geduldig auf Entwarnung warten",
  ]

  return (
    <div className="space-y-6">
      <Card className="border-accent bg-accent/5">
        <CardHeader>
          <CardTitle className="flex items-center text-accent">
            <AlertTriangle className="h-6 w-6 mr-2" />
            Notfall-Informationen
          </CardTitle>
          <CardDescription>Wichtige Informationen für den Katastrophenfall und die Vorbereitung</CardDescription>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="preparation">Vorbereitung</TabsTrigger>
          <TabsTrigger value="emergency">Notfall</TabsTrigger>
          <TabsTrigger value="bunker">Bunker-Verhalten</TabsTrigger>
          <TabsTrigger value="contacts">Kontakte</TabsTrigger>
        </TabsList>

        <TabsContent value="preparation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notvorrat für 10 Tage</CardTitle>
              <CardDescription>Grundausstattung für den Katastrophenfall pro Person</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6">
                {emergencySupplies.map((supply) => {
                  const IconComponent = supply.icon
                  return (
                    <div key={supply.category} className="flex items-start space-x-4">
                      <div className="bg-primary/10 p-2 rounded-lg">
                        <IconComponent className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold mb-2">{supply.category}</h4>
                        <ul className="space-y-1">
                          {supply.items.map((item, index) => (
                            <li key={index} className="text-sm text-muted-foreground flex items-center">
                              <CheckCircle className="h-3 w-3 mr-2 text-green-500" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>Tipp:</strong> Überprüfen Sie Ihren Notvorrat alle 6 Monate und tauschen Sie abgelaufene
              Lebensmittel und Medikamente aus.
            </AlertDescription>
          </Alert>
        </TabsContent>

        <TabsContent value="emergency" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Warnsignale verstehen</CardTitle>
              <CardDescription>Bedeutung der verschiedenen Sirenensignale</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {warningSignals.map((signal, index) => (
                  <div key={index} className="flex items-start space-x-4 p-4 rounded-lg border">
                    <div
                      className={`p-2 rounded-full ${
                        signal.type === "safe"
                          ? "bg-green-100"
                          : signal.type === "warning"
                            ? "bg-yellow-100"
                            : "bg-red-100"
                      }`}
                    >
                      {signal.type === "safe" ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : signal.type === "warning" ? (
                        <AlertTriangle className="h-5 w-5 text-yellow-600" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="font-semibold">{signal.name}</h4>
                        <Badge
                          variant={
                            signal.type === "safe" ? "default" : signal.type === "warning" ? "secondary" : "destructive"
                          }
                        >
                          {signal.meaning}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{signal.action}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Alert className="border-red-200 bg-red-50">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Wichtig:</strong> Bei Warnsignalen sofort Radio oder Fernsehen einschalten und auf offizielle
              Durchsagen achten. Keine sozialen Medien als Informationsquelle nutzen!
            </AlertDescription>
          </Alert>
        </TabsContent>

        <TabsContent value="bunker" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Verhalten im Schutzraum</CardTitle>
              <CardDescription>Wichtige Regeln für den Aufenthalt in Bunkern und Schutzräumen</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                {bunkerBehavior.map((rule, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="bg-primary/10 rounded-full p-1 mt-0.5">
                      <div className="w-2 h-2 bg-primary rounded-full" />
                    </div>
                    <p className="text-sm">{rule}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Was mitbringen?</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2 text-green-600">Mitbringen</h4>
                  <ul className="space-y-1 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-3 w-3 mr-2 text-green-500" />
                      Personalausweis
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-3 w-3 mr-2 text-green-500" />
                      Medikamente
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-3 w-3 mr-2 text-green-500" />
                      Wasser (1-2 Liter)
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-3 w-3 mr-2 text-green-500" />
                      Handy + Ladegerät
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-3 w-3 mr-2 text-green-500" />
                      Warme Kleidung
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 text-red-600">Nicht mitbringen</h4>
                  <ul className="space-y-1 text-sm">
                    <li className="flex items-center">
                      <XCircle className="h-3 w-3 mr-2 text-red-500" />
                      Haustiere
                    </li>
                    <li className="flex items-center">
                      <XCircle className="h-3 w-3 mr-2 text-red-500" />
                      Große Gepäckstücke
                    </li>
                    <li className="flex items-center">
                      <XCircle className="h-3 w-3 mr-2 text-red-500" />
                      Alkohol
                    </li>
                    <li className="flex items-center">
                      <XCircle className="h-3 w-3 mr-2 text-red-500" />
                      Waffen
                    </li>
                    <li className="flex items-center">
                      <XCircle className="h-3 w-3 mr-2 text-red-500" />
                      Offenes Feuer
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contacts" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Wichtige Notrufnummern</CardTitle>
              <CardDescription>Speichern Sie diese Nummern in Ihrem Handy</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {emergencyContacts.map((contact, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <h4 className="font-semibold">{contact.name}</h4>
                      <p className="text-sm text-muted-foreground">{contact.description}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="font-mono text-lg">
                        {contact.number}
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => (window.location.href = `tel:${contact.number.replace(/\s/g, "")}`)}
                      >
                        <Phone className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Offizielle Warn-Apps</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border rounded">
                  <div>
                    <h4 className="font-semibold">NINA</h4>
                    <p className="text-sm text-muted-foreground">Notfall-Informations- und Nachrichten-App</p>
                  </div>
                  <Badge variant="secondary">Empfohlen</Badge>
                </div>
                <div className="flex items-center justify-between p-3 border rounded">
                  <div>
                    <h4 className="font-semibold">KATWARN</h4>
                    <p className="text-sm text-muted-foreground">Katastrophenwarnung für Ihre Region</p>
                  </div>
                  <Badge variant="outline">Optional</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Alert>
            <Clock className="h-4 w-4" />
            <AlertDescription>
              <strong>Wichtig:</strong> Notrufnummern sind 24/7 erreichbar. Bei lebensbedrohlichen Situationen immer
              sofort die 112 wählen!
            </AlertDescription>
          </Alert>
        </TabsContent>
      </Tabs>
    </div>
  )
}
