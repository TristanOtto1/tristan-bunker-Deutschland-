"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { MapPin, Navigation, Shield, AlertCircle, Loader2, RefreshCw } from "lucide-react"
import { useLocation } from "@/hooks/use-location"
import { calculateDistance, formatDistance } from "@/utils/distance"

interface Bunker {
  id: number
  name: string
  address: string
  capacity: number
  type: string
  distance: number
  coordinates: { lat: number; lng: number }
  status: string
}

interface LocationFinderProps {
  bunkers: Bunker[]
  onBunkerSelect: (bunker: Bunker) => void
}

export default function LocationFinder({ bunkers, onBunkerSelect }: LocationFinderProps) {
  const { coordinates, error, loading, requestLocation } = useLocation()
  const [sortedBunkers, setSortedBunkers] = useState<Bunker[]>([])

  const findNearestBunkers = () => {
    if (!coordinates) return

    const bunkersWithDistance = bunkers.map((bunker) => ({
      ...bunker,
      distance: calculateDistance(coordinates.lat, coordinates.lng, bunker.coordinates.lat, bunker.coordinates.lng),
    }))

    const sorted = bunkersWithDistance.sort((a, b) => a.distance - b.distance)
    setSortedBunkers(sorted.slice(0, 3)) // Show top 3 nearest
  }

  const getRouteToGoogle = (bunker: Bunker) => {
    if (coordinates) {
      const url = `https://www.google.com/maps/dir/${coordinates.lat},${coordinates.lng}/${bunker.coordinates.lat},${bunker.coordinates.lng}`
      window.open(url, "_blank")
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Verfügbar":
        return "bg-green-500"
      case "Begrenzt":
        return "bg-yellow-500"
      case "Voll":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <MapPin className="h-5 w-5 mr-2" />
          Standort-basierte Suche
        </CardTitle>
        <CardDescription>Finden Sie die nächstgelegenen Bunker zu Ihrem aktuellen Standort</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Location Status */}
        {loading && (
          <Alert>
            <Loader2 className="h-4 w-4 animate-spin" />
            <AlertDescription>Standort wird ermittelt...</AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {error}
              <Button variant="outline" size="sm" className="ml-2 bg-transparent" onClick={requestLocation}>
                <RefreshCw className="h-4 w-4 mr-1" />
                Erneut versuchen
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {coordinates && (
          <Alert className="border-green-200 bg-green-50">
            <MapPin className="h-4 w-4" />
            <AlertDescription>
              <strong>Standort gefunden!</strong> Koordinaten: {coordinates.lat.toFixed(4)},{" "}
              {coordinates.lng.toFixed(4)}
            </AlertDescription>
          </Alert>
        )}

        {/* Find Nearest Button */}
        <Button className="w-full" size="lg" onClick={findNearestBunkers} disabled={!coordinates}>
          <Navigation className="h-4 w-4 mr-2" />
          Nächste Bunker finden
        </Button>

        {/* Nearest Bunkers Results */}
        {sortedBunkers.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-semibold text-sm">Nächstgelegene Bunker:</h4>
            {sortedBunkers.map((bunker, index) => (
              <Card
                key={bunker.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => onBunkerSelect(bunker)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <Badge variant="secondary" className="text-xs">
                          #{index + 1}
                        </Badge>
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(bunker.status)}`} />
                        <span className="font-medium text-sm">{bunker.name}</span>
                      </div>

                      <p className="text-xs text-muted-foreground mb-2">{bunker.address}</p>

                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center space-x-3">
                          <span className="flex items-center">
                            <Shield className="h-3 w-3 mr-1" />
                            {bunker.type}
                          </span>
                          <span>{bunker.capacity} Personen</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className="text-xs font-bold text-primary">
                            {formatDistance(bunker.distance)}
                          </Badge>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-6 text-xs px-2 bg-transparent"
                            onClick={(e) => {
                              e.stopPropagation()
                              getRouteToGoogle(bunker)
                            }}
                          >
                            Route
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Emergency Instructions */}
        <Alert className="border-accent bg-accent/10">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-xs">
            <strong>Notfall-Tipp:</strong> Merken Sie sich den Weg zum nächstgelegenen Bunker. Im Ernstfall haben Sie
            möglicherweise keinen Internetzugang.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  )
}
