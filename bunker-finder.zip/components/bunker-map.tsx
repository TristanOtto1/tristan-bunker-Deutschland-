"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Navigation, Shield, Maximize2, Minimize2 } from "lucide-react"

interface Bunker {
  id: number
  name: string
  address: string
  capacity: number
  type: string
  distance: number
  coordinates: { lat: number; lng: number }
  status: string
}

interface BunkerMapProps {
  bunkers: Bunker[]
  userLocation: { lat: number; lng: number } | null
  selectedBunker: Bunker | null
  onBunkerSelect: (bunker: Bunker) => void
}

export default function BunkerMap({ bunkers, userLocation, selectedBunker, onBunkerSelect }: BunkerMapProps) {
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [mapCenter, setMapCenter] = useState({ lat: 52.52, lng: 13.405 }) // Berlin center
  const mapRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (userLocation) {
      setMapCenter(userLocation)
    }
  }, [userLocation])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Verfügbar":
        return "bg-green-500"
      case "Begrenzt":
        return "bg-yellow-500"
      case "Voll":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
    const R = 6371 // Earth's radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180
    const dLng = ((lng2 - lng1) * Math.PI) / 180
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) * Math.sin(dLng / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }

  const getRouteToGoogle = (bunker: Bunker) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${bunker.coordinates.lat},${bunker.coordinates.lng}&travelmode=driving`
    window.open(url, "_blank")
  }

  return (
    <Card className={`${isFullscreen ? "fixed inset-4 z-50" : "h-96"} transition-all duration-300`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="flex items-center">
          <MapPin className="h-5 w-5 mr-2" />
          Bunker-Karte Deutschland
        </CardTitle>
        <Button variant="outline" size="sm" onClick={() => setIsFullscreen(!isFullscreen)}>
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </Button>
      </CardHeader>
      <CardContent className="p-0 relative">
        <div
          ref={mapRef}
          className={`relative bg-muted ${isFullscreen ? "h-[calc(100vh-8rem)]" : "h-80"} overflow-hidden`}
        >
          {/* Simplified Map Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-green-100">
            {/* Grid pattern to simulate map */}
            <div className="absolute inset-0 opacity-20">
              <div className="grid grid-cols-12 grid-rows-8 h-full">
                {Array.from({ length: 96 }).map((_, i) => (
                  <div key={i} className="border border-gray-300" />
                ))}
              </div>
            </div>

            {/* User Location Marker */}
            {userLocation && (
              <div
                className="absolute transform -translate-x-1/2 -translate-y-1/2 z-20"
                style={{
                  left: "50%",
                  top: "50%",
                }}
              >
                <div className="relative">
                  <div className="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg animate-pulse" />
                  <div className="absolute -top-1 -left-1 w-6 h-6 bg-blue-500 rounded-full opacity-30 animate-ping" />
                </div>
                <div className="absolute top-6 left-1/2 transform -translate-x-1/2 bg-white px-2 py-1 rounded shadow text-xs font-medium whitespace-nowrap">
                  Ihr Standort
                </div>
              </div>
            )}

            {/* Bunker Markers */}
            {bunkers.map((bunker, index) => {
              const isSelected = selectedBunker?.id === bunker.id
              // Position bunkers around the map area
              const positions = [
                { left: "25%", top: "30%" },
                { left: "70%", top: "25%" },
                { left: "60%", top: "60%" },
                { left: "30%", top: "70%" },
                { left: "80%", top: "45%" },
                { left: "15%", top: "55%" },
              ]
              const position = positions[index % positions.length]

              return (
                <div
                  key={bunker.id}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10"
                  style={position}
                  onClick={() => onBunkerSelect(bunker)}
                >
                  <div className={`relative ${isSelected ? "scale-125" : "hover:scale-110"} transition-transform`}>
                    <div
                      className={`w-6 h-6 rounded-full border-2 border-white shadow-lg flex items-center justify-center ${
                        bunker.status === "Verfügbar"
                          ? "bg-green-500"
                          : bunker.status === "Begrenzt"
                            ? "bg-yellow-500"
                            : "bg-red-500"
                      }`}
                    >
                      <Shield className="h-3 w-3 text-white" />
                    </div>
                    {isSelected && (
                      <div className="absolute -top-2 -left-2 w-10 h-10 border-2 border-primary rounded-full animate-pulse" />
                    )}
                  </div>

                  {/* Bunker Info Popup */}
                  {isSelected && (
                    <div className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-white p-3 rounded-lg shadow-lg border min-w-64 z-30">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-sm">{bunker.name}</h4>
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(bunker.status)}`} />
                      </div>
                      <p className="text-xs text-muted-foreground mb-2">{bunker.address}</p>
                      <div className="flex items-center justify-between text-xs">
                        <span>{bunker.capacity} Personen</span>
                        <Badge variant="outline" className="text-xs">
                          {bunker.type}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-primary font-medium">{bunker.distance} km</span>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-6 text-xs px-2 bg-transparent"
                          onClick={(e) => {
                            e.stopPropagation()
                            getRouteToGoogle(bunker)
                          }}
                        >
                          <Navigation className="h-3 w-3 mr-1" />
                          Route
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>

          {/* Map Controls */}
          <div className="absolute top-4 right-4 space-y-2 z-20">
            <Button variant="secondary" size="sm" className="shadow-lg">
              <MapPin className="h-4 w-4" />
            </Button>
            <div className="bg-white rounded shadow-lg p-2">
              <div className="space-y-1 text-xs">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-2" />
                  <span>Verfügbar</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2" />
                  <span>Begrenzt</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-red-500 rounded-full mr-2" />
                  <span>Voll</span>
                </div>
              </div>
            </div>
          </div>

          {/* Distance Scale */}
          <div className="absolute bottom-4 left-4 bg-white px-2 py-1 rounded shadow text-xs">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-0.5 bg-black" />
              <span>1 km</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
