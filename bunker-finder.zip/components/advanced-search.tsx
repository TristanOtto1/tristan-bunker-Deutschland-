"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, X } from "lucide-react"

interface SearchFilters {
  query: string
  types: string[]
  statuses: string[]
  minCapacity: number
  accessibleOnly: boolean
  city: string
  state: string
}

interface AdvancedSearchProps {
  onSearch: (filters: SearchFilters) => void
  onReset: () => void
  resultCount: number
}

const bunkerTypes = ["Zivilbunker", "Schutzraum", "Notunterkunft", "Hochbunker", "Tiefbunker"]
const bunkerStatuses = ["Verfügbar", "Begrenzt", "Voll", "Wartung"]
const germanStates = [
  "Baden-Württemberg",
  "Bayern",
  "Berlin",
  "Brandenburg",
  "Bremen",
  "Hamburg",
  "Hessen",
  "Mecklenburg-Vorpommern",
  "Niedersachsen",
  "Nordrhein-Westfalen",
  "Rheinland-Pfalz",
  "Saarland",
  "Sachsen",
  "Sachsen-Anhalt",
  "Schleswig-Holstein",
  "Thüringen",
]

export default function AdvancedSearch({ onSearch, onReset, resultCount }: AdvancedSearchProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [filters, setFilters] = useState<SearchFilters>({
    query: "",
    types: [],
    statuses: ["Verfügbar", "Begrenzt"],
    minCapacity: 0,
    accessibleOnly: false,
    city: "",
    state: "",
  })

  const handleSearch = () => {
    onSearch(filters)
  }

  const handleReset = () => {
    const resetFilters: SearchFilters = {
      query: "",
      types: [],
      statuses: ["Verfügbar", "Begrenzt"],
      minCapacity: 0,
      accessibleOnly: false,
      city: "",
      state: "",
    }
    setFilters(resetFilters)
    onReset()
  }

  const handleTypeChange = (type: string, checked: boolean) => {
    setFilters((prev) => ({
      ...prev,
      types: checked ? [...prev.types, type] : prev.types.filter((t) => t !== type),
    }))
  }

  const handleStatusChange = (status: string, checked: boolean) => {
    setFilters((prev) => ({
      ...prev,
      statuses: checked ? [...prev.statuses, status] : prev.statuses.filter((s) => s !== status),
    }))
  }

  const getActiveFilterCount = () => {
    let count = 0
    if (filters.query) count++
    if (filters.types.length > 0) count++
    if (filters.statuses.length < 4) count++
    if (filters.minCapacity > 0) count++
    if (filters.accessibleOnly) count++
    if (filters.city) count++
    if (filters.state) count++
    return count
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <Search className="h-5 w-5 mr-2" />
              Erweiterte Suche
            </CardTitle>
            <CardDescription>Finden Sie Bunker mit spezifischen Kriterien</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={() => setIsExpanded(!isExpanded)}>
            <Filter className="h-4 w-4 mr-2" />
            Filter {getActiveFilterCount() > 0 && `(${getActiveFilterCount()})`}
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Basic Search */}
        <div className="space-y-2">
          <Label htmlFor="search-query">Suchbegriff</Label>
          <Input
            id="search-query"
            placeholder="Name, Adresse, Stadt oder Ausstattung..."
            value={filters.query}
            onChange={(e) => setFilters((prev) => ({ ...prev, query: e.target.value }))}
          />
        </div>

        {/* Expanded Filters */}
        {isExpanded && (
          <div className="space-y-6 pt-4 border-t">
            {/* Location Filters */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">Stadt</Label>
                <Input
                  id="city"
                  placeholder="z.B. Berlin, München..."
                  value={filters.city}
                  onChange={(e) => setFilters((prev) => ({ ...prev, city: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="state">Bundesland</Label>
                <Select
                  value={filters.state}
                  onValueChange={(value) => setFilters((prev) => ({ ...prev, state: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Bundesland wählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle Bundesländer</SelectItem>
                    {germanStates.map((state) => (
                      <SelectItem key={state} value={state}>
                        {state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Bunker Types */}
            <div className="space-y-3">
              <Label>Bunkertyp</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {bunkerTypes.map((type) => (
                  <div key={type} className="flex items-center space-x-2">
                    <Checkbox
                      id={`type-${type}`}
                      checked={filters.types.includes(type)}
                      onCheckedChange={(checked) => handleTypeChange(type, checked as boolean)}
                    />
                    <Label htmlFor={`type-${type}`} className="text-sm">
                      {type}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Status Filter */}
            <div className="space-y-3">
              <Label>Verfügbarkeit</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {bunkerStatuses.map((status) => (
                  <div key={status} className="flex items-center space-x-2">
                    <Checkbox
                      id={`status-${status}`}
                      checked={filters.statuses.includes(status)}
                      onCheckedChange={(checked) => handleStatusChange(status, checked as boolean)}
                    />
                    <Label htmlFor={`status-${status}`} className="text-sm">
                      {status}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Capacity Filter */}
            <div className="space-y-3">
              <Label>Mindestkapazität: {filters.minCapacity} Personen</Label>
              <Slider
                value={[filters.minCapacity]}
                onValueChange={(value) => setFilters((prev) => ({ ...prev, minCapacity: value[0] }))}
                max={1000}
                step={50}
                className="w-full"
              />
            </div>

            {/* Accessibility */}
            <div className="flex items-center space-x-2">
              <Checkbox
                id="accessibility"
                checked={filters.accessibleOnly}
                onCheckedChange={(checked) => setFilters((prev) => ({ ...prev, accessibleOnly: checked as boolean }))}
              />
              <Label htmlFor="accessibility">Nur barrierefreie Bunker anzeigen</Label>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center space-x-2">
            <Badge variant="secondary" className="bg-accent text-accent-foreground">
              {resultCount} Ergebnisse
            </Badge>
            {getActiveFilterCount() > 0 && (
              <Button variant="ghost" size="sm" onClick={handleReset}>
                <X className="h-4 w-4 mr-1" />
                Filter zurücksetzen
              </Button>
            )}
          </div>

          <Button onClick={handleSearch}>
            <Search className="h-4 w-4 mr-2" />
            Suchen
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
