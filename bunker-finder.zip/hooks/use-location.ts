"use client"

import { useState, useEffect } from "react"

interface LocationState {
  coordinates: { lat: number; lng: number } | null
  error: string | null
  loading: boolean
}

export function useLocation() {
  const [location, setLocation] = useState<LocationState>({
    coordinates: null,
    error: null,
    loading: true,
  })

  const requestLocation = () => {
    if (!navigator.geolocation) {
      setLocation({
        coordinates: null,
        error: "Geolocation wird von diesem Browser nicht unterstützt",
        loading: false,
      })
      return
    }

    setLocation((prev) => ({ ...prev, loading: true, error: null }))

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          coordinates: {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          },
          error: null,
          loading: false,
        })
      },
      (error) => {
        let errorMessage = "Standort konnte nicht ermittelt werden"

        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Standortzugriff wurde verweigert"
            break
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Standortinformationen sind nicht verfügbar"
            break
          case error.TIMEOUT:
            errorMessage = "Zeitüberschreitung bei der Standortermittlung"
            break
        }

        setLocation({
          coordinates: null,
          error: errorMessage,
          loading: false,
        })
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000, // 5 minutes
      },
    )
  }

  useEffect(() => {
    requestLocation()
  }, [])

  return {
    ...location,
    requestLocation,
  }
}
