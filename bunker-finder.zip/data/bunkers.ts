export interface Bunker {
  id: number
  name: string
  address: string
  city: string
  state: string
  postalCode: string
  capacity: number
  type: "Zivilbunker" | "Schutzraum" | "Notunterkunft" | "Hochbunker" | "Tiefbunker"
  coordinates: { lat: number; lng: number }
  status: "Verfügbar" | "Begrenzt" | "Voll" | "Wartung"
  facilities: string[]
  accessibility: boolean
  emergencyContact?: string
  description?: string
  lastUpdated: string
}

// Comprehensive bunker database for Germany
export const bunkersDatabase: Bunker[] = [
  {
    id: 1,
    name: "Zivilschutzanlage Berlin-Mitte",
    address: "Unter den Linden 1",
    city: "Berlin",
    state: "Berlin",
    postalCode: "10117",
    capacity: 500,
    type: "Zivilbunker",
    coordinates: { lat: 52.517, lng: 13.3888 },
    status: "Verfügbar",
    facilities: ["Sanitäranlagen", "Belüftung", "Notstrom", "Erste Hilfe"],
    accessibility: true,
    emergencyContact: "+49 30 12345678",
    description: "Moderner Zivilschutzbunker im Herzen Berlins mit vollständiger Ausstattung.",
    lastUpdated: "2024-01-15",
  },
  {
    id: 2,
    name: "Schutzraum Hamburg-Altona",
    address: "Große Bergstraße 160",
    city: "Hamburg",
    state: "Hamburg",
    postalCode: "22767",
    capacity: 300,
    type: "Schutzraum",
    coordinates: { lat: 53.5511, lng: 9.9937 },
    status: "Verfügbar",
    facilities: ["Sanitäranlagen", "Belüftung", "Notstrom"],
    accessibility: false,
    emergencyContact: "+49 40 87654321",
    description: "Schutzraum in Hamburg-Altona mit grundlegender Ausstattung.",
    lastUpdated: "2024-01-10",
  },
  {
    id: 3,
    name: "Bunkeranlage München-Schwabing",
    address: "Leopoldstraße 85",
    city: "München",
    state: "Bayern",
    postalCode: "80802",
    capacity: 750,
    type: "Tiefbunker",
    coordinates: { lat: 48.1351, lng: 11.582 },
    status: "Begrenzt",
    facilities: ["Sanitäranlagen", "Belüftung", "Notstrom", "Erste Hilfe", "Küche"],
    accessibility: true,
    emergencyContact: "+49 89 11223344",
    description: "Großer Tiefbunker mit erweiterten Einrichtungen und Küche.",
    lastUpdated: "2024-01-12",
  },
  {
    id: 4,
    name: "Notunterkunft Köln-Innenstadt",
    address: "Domplatz 3",
    city: "Köln",
    state: "Nordrhein-Westfalen",
    postalCode: "50667",
    capacity: 400,
    type: "Notunterkunft",
    coordinates: { lat: 50.9375, lng: 6.9603 },
    status: "Verfügbar",
    facilities: ["Sanitäranlagen", "Belüftung", "Erste Hilfe"],
    accessibility: true,
    emergencyContact: "+49 221 55667788",
    description: "Zentral gelegene Notunterkunft in der Kölner Innenstadt.",
    lastUpdated: "2024-01-08",
  },
  {
    id: 5,
    name: "Hochbunker Frankfurt-Sachsenhausen",
    address: "Schweizer Straße 45",
    city: "Frankfurt am Main",
    state: "Hessen",
    postalCode: "60594",
    capacity: 600,
    type: "Hochbunker",
    coordinates: { lat: 50.1109, lng: 8.6821 },
    status: "Verfügbar",
    facilities: ["Sanitäranlagen", "Belüftung", "Notstrom", "Erste Hilfe", "Kommunikation"],
    accessibility: false,
    emergencyContact: "+49 69 99887766",
    description: "Historischer Hochbunker mit moderner Ausstattung.",
    lastUpdated: "2024-01-14",
  },
  {
    id: 6,
    name: "Zivilschutzanlage Stuttgart-Mitte",
    address: "Königstraße 28",
    city: "Stuttgart",
    state: "Baden-Württemberg",
    postalCode: "70173",
    capacity: 450,
    type: "Zivilbunker",
    coordinates: { lat: 48.7758, lng: 9.1829 },
    status: "Wartung",
    facilities: ["Sanitäranlagen", "Belüftung", "Notstrom"],
    accessibility: true,
    emergencyContact: "+49 711 44556677",
    description: "Zivilschutzbunker in der Stuttgarter Innenstadt, derzeit in Wartung.",
    lastUpdated: "2024-01-05",
  },
  {
    id: 7,
    name: "Schutzraum Düsseldorf-Altstadt",
    address: "Rheinuferpromenade 12",
    city: "Düsseldorf",
    state: "Nordrhein-Westfalen",
    postalCode: "40213",
    capacity: 350,
    type: "Schutzraum",
    coordinates: { lat: 51.2277, lng: 6.7735 },
    status: "Verfügbar",
    facilities: ["Sanitäranlagen", "Belüftung", "Erste Hilfe"],
    accessibility: true,
    emergencyContact: "+49 211 33445566",
    description: "Schutzraum in der Düsseldorfer Altstadt nahe dem Rhein.",
    lastUpdated: "2024-01-11",
  },
  {
    id: 8,
    name: "Tiefbunker Hannover-Zentrum",
    address: "Georgstraße 50",
    city: "Hannover",
    state: "Niedersachsen",
    postalCode: "30159",
    capacity: 800,
    type: "Tiefbunker",
    coordinates: { lat: 52.3759, lng: 9.732 },
    status: "Begrenzt",
    facilities: ["Sanitäranlagen", "Belüftung", "Notstrom", "Erste Hilfe", "Küche", "Kommunikation"],
    accessibility: true,
    emergencyContact: "+49 511 22334455",
    description: "Großer Tiefbunker mit umfassender Ausstattung im Zentrum Hannovers.",
    lastUpdated: "2024-01-13",
  },
  {
    id: 9,
    name: "Notunterkunft Bremen-Altstadt",
    address: "Am Markt 15",
    city: "Bremen",
    state: "Bremen",
    postalCode: "28195",
    capacity: 250,
    type: "Notunterkunft",
    coordinates: { lat: 53.0759, lng: 8.8072 },
    status: "Verfügbar",
    facilities: ["Sanitäranlagen", "Belüftung", "Erste Hilfe"],
    accessibility: false,
    emergencyContact: "+49 421 66778899",
    description: "Kompakte Notunterkunft in der Bremer Altstadt.",
    lastUpdated: "2024-01-09",
  },
  {
    id: 10,
    name: "Zivilbunker Leipzig-Zentrum",
    address: "Augustusplatz 10",
    city: "Leipzig",
    state: "Sachsen",
    postalCode: "04109",
    capacity: 550,
    type: "Zivilbunker",
    coordinates: { lat: 51.3397, lng: 12.3731 },
    status: "Verfügbar",
    facilities: ["Sanitäranlagen", "Belüftung", "Notstrom", "Erste Hilfe", "Kommunikation"],
    accessibility: true,
    emergencyContact: "+49 341 77889900",
    description: "Moderner Zivilbunker am Augustusplatz mit guter Ausstattung.",
    lastUpdated: "2024-01-16",
  },
]

// Search and filter functions
export function searchBunkers(query: string, bunkers: Bunker[] = bunkersDatabase): Bunker[] {
  if (!query.trim()) return bunkers

  const searchTerm = query.toLowerCase().trim()

  return bunkers.filter(
    (bunker) =>
      bunker.name.toLowerCase().includes(searchTerm) ||
      bunker.address.toLowerCase().includes(searchTerm) ||
      bunker.city.toLowerCase().includes(searchTerm) ||
      bunker.state.toLowerCase().includes(searchTerm) ||
      bunker.type.toLowerCase().includes(searchTerm) ||
      bunker.postalCode.includes(searchTerm) ||
      bunker.facilities.some((facility) => facility.toLowerCase().includes(searchTerm)),
  )
}

export function filterBunkersByStatus(status: string[], bunkers: Bunker[] = bunkersDatabase): Bunker[] {
  if (status.length === 0) return bunkers
  return bunkers.filter((bunker) => status.includes(bunker.status))
}

export function filterBunkersByType(types: string[], bunkers: Bunker[] = bunkersDatabase): Bunker[] {
  if (types.length === 0) return bunkers
  return bunkers.filter((bunker) => types.includes(bunker.type))
}

export function filterBunkersByCapacity(minCapacity: number, bunkers: Bunker[] = bunkersDatabase): Bunker[] {
  return bunkers.filter((bunker) => bunker.capacity >= minCapacity)
}

export function filterBunkersByAccessibility(accessibleOnly: boolean, bunkers: Bunker[] = bunkersDatabase): Bunker[] {
  if (!accessibleOnly) return bunkers
  return bunkers.filter((bunker) => bunker.accessibility)
}

export function getBunkerById(id: number): Bunker | undefined {
  return bunkersDatabase.find((bunker) => bunker.id === id)
}

export function getBunkersByCity(city: string): Bunker[] {
  return bunkersDatabase.filter((bunker) => bunker.city.toLowerCase() === city.toLowerCase())
}

export function getBunkersByState(state: string): Bunker[] {
  return bunkersDatabase.filter((bunker) => bunker.state.toLowerCase() === state.toLowerCase())
}
