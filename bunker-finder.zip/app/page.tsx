"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MapPin, Navigation, Shield, AlertTriangle, Phone, Menu, X, Accessibility, Info } from "lucide-react"
import BunkerMap from "@/components/bunker-map"
import LocationFinder from "@/components/location-finder"
import AdvancedSearch from "@/components/advanced-search"
import { useLocation } from "@/hooks/use-location"
import Link from "next/link"
import {
  bunkersDatabase,
  searchBunkers,
  filterBunkersByStatus,
  filterBunkersByType,
  filterBunkersByCapacity,
  filterBunkersByAccessibility,
  getBunkersByState,
  type Bunker,
} from "@/data/bunkers"

interface SearchFilters {
  query: string
  types: string[]
  statuses: string[]
  minCapacity: number
  accessibleOnly: boolean
  city: string
  state: string
}

export default function BunkerFinderApp() {
  const [filteredBunkers, setFilteredBunkers] = useState<Bunker[]>(bunkersDatabase)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [selectedBunker, setSelectedBunker] = useState<Bunker | null>(null)
  const { coordinates: userLocation } = useLocation()

  const handleEmergencyCall = () => {
    window.location.href = "tel:112"
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Verfügbar":
        return "bg-green-500"
      case "Begrenzt":
        return "bg-yellow-500"
      case "Voll":
        return "bg-red-500"
      case "Wartung":
        return "bg-gray-500"
      default:
        return "bg-gray-500"
    }
  }

  const handleAdvancedSearch = (filters: SearchFilters) => {
    let results = bunkersDatabase

    // Apply text search
    if (filters.query) {
      results = searchBunkers(filters.query, results)
    }

    // Apply location filters
    if (filters.city) {
      results = results.filter((bunker) => bunker.city.toLowerCase().includes(filters.city.toLowerCase()))
    }

    if (filters.state) {
      results = getBunkersByState(filters.state).filter((bunker) => results.includes(bunker))
    }

    // Apply type filter
    if (filters.types.length > 0) {
      results = filterBunkersByType(filters.types, results)
    }

    // Apply status filter
    if (filters.statuses.length > 0) {
      results = filterBunkersByStatus(filters.statuses, results)
    }

    // Apply capacity filter
    if (filters.minCapacity > 0) {
      results = filterBunkersByCapacity(filters.minCapacity, results)
    }

    // Apply accessibility filter
    if (filters.accessibleOnly) {
      results = filterBunkersByAccessibility(true, results)
    }

    setFilteredBunkers(results)
  }

  const handleResetSearch = () => {
    setFilteredBunkers(bunkersDatabase)
  }

  const getRouteToGoogle = (bunker: Bunker) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${bunker.coordinates.lat},${bunker.coordinates.lng}&travelmode=driving`
    window.open(url, "_blank")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Shield className="h-8 w-8" />
              <div>
                <h1 className="text-xl font-bold">Bunker Finder Deutschland</h1>
                <p className="text-sm opacity-90">Katastrophenhilfe & Zivilschutz</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={handleEmergencyCall}
                className="bg-accent text-accent-foreground hover:bg-accent/90"
              >
                <Phone className="h-4 w-4 mr-2" />
                Notruf 112
              </Button>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="md:hidden text-primary-foreground"
              >
                {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="mt-4 md:hidden">
              <nav className="space-y-2">
                <Button variant="ghost" className="w-full justify-start text-primary-foreground">
                  <MapPin className="h-4 w-4 mr-2" />
                  Karte anzeigen
                </Button>
                <Link href="/emergency">
                  <Button variant="ghost" className="w-full justify-start text-primary-foreground">
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Notfall-Infos
                  </Button>
                </Link>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Emergency Alert */}
      <Alert className="m-4 border-accent bg-accent/10">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription className="font-medium">
          <strong>Wichtiger Hinweis:</strong> Diese App dient der Vorbereitung auf Notfälle. Im akuten Notfall wählen
          Sie sofort den Notruf 112.
          <Link href="/emergency" className="ml-2 underline hover:no-underline">
            Mehr Notfall-Informationen
          </Link>
        </AlertDescription>
      </Alert>

      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <BunkerMap
            bunkers={filteredBunkers}
            userLocation={userLocation}
            selectedBunker={selectedBunker}
            onBunkerSelect={setSelectedBunker}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Search and Location Services */}
          <div className="lg:col-span-1 space-y-6">
            <AdvancedSearch
              onSearch={handleAdvancedSearch}
              onReset={handleResetSearch}
              resultCount={filteredBunkers.length}
            />

            <LocationFinder bunkers={bunkersDatabase} onBunkerSelect={setSelectedBunker} />

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Schnellübersicht</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">{filteredBunkers.length}</div>
                    <div className="text-sm text-muted-foreground">Bunker gefunden</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">
                      {filteredBunkers.reduce((sum, b) => sum + b.capacity, 0)}
                    </div>
                    <div className="text-sm text-muted-foreground">Gesamtkapazität</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-accent bg-accent/5">
              <CardHeader>
                <CardTitle className="flex items-center text-accent">
                  <Info className="h-5 w-5 mr-2" />
                  Notfall-Vorbereitung
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Informieren Sie sich über Warnsignale, Notvorräte und richtiges Verhalten im Katastrophenfall.
                </p>
                <Link href="/emergency">
                  <Button variant="outline" size="sm" className="w-full bg-transparent">
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Notfall-Informationen
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Bunker List */}
          <div className="lg:col-span-2">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Verfügbare Schutzräume</h2>
                <Badge variant="secondary" className="bg-accent text-accent-foreground">
                  {filteredBunkers.length} Ergebnisse
                </Badge>
              </div>

              <div className="grid gap-4">
                {filteredBunkers.map((bunker) => (
                  <Card
                    key={bunker.id}
                    className="hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => setSelectedBunker(bunker)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="font-semibold text-lg">{bunker.name}</h3>
                            <div className={`w-3 h-3 rounded-full ${getStatusColor(bunker.status)}`} />
                            <Badge variant="outline">{bunker.status}</Badge>
                            {bunker.accessibility && (
                              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                                <Accessibility className="h-3 w-3 mr-1" />
                                Barrierefrei
                              </Badge>
                            )}
                          </div>

                          <p className="text-muted-foreground mb-2">
                            {bunker.address}, {bunker.city}, {bunker.state}
                          </p>

                          <div className="flex items-center space-x-4 text-sm mb-2">
                            <span className="flex items-center">
                              <Shield className="h-4 w-4 mr-1" />
                              {bunker.type}
                            </span>
                            <span>Kapazität: {bunker.capacity} Personen</span>
                          </div>

                          <div className="flex flex-wrap gap-1 mt-2">
                            {bunker.facilities.slice(0, 3).map((facility) => (
                              <Badge key={facility} variant="outline" className="text-xs">
                                {facility}
                              </Badge>
                            ))}
                            {bunker.facilities.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{bunker.facilities.length - 3} weitere
                              </Badge>
                            )}
                          </div>
                        </div>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation()
                            getRouteToGoogle(bunker)
                          }}
                        >
                          <Navigation className="h-4 w-4 mr-2" />
                          Route
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {filteredBunkers.length === 0 && (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Shield className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Keine Bunker gefunden</h3>
                    <p className="text-muted-foreground mb-4">
                      Versuchen Sie andere Suchkriterien oder erweitern Sie Ihren Suchbereich.
                    </p>
                    <Button variant="outline" onClick={handleResetSearch}>
                      Filter zurücksetzen
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Footer */}
      <footer className="bg-muted mt-12 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <h3 className="font-semibold mb-2">Notrufnummern</h3>
              <p className="text-sm text-muted-foreground">
                Polizei, Feuerwehr, Rettungsdienst: <strong>112</strong>
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Katastrophenschutz</h3>
              <p className="text-sm text-muted-foreground">Bundesamt für Bevölkerungsschutz und Katastrophenhilfe</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Weitere Hilfe</h3>
              <p className="text-sm text-muted-foreground">NINA-App für Warnmeldungen installieren</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
